
from flask import Flask, jsonify, request, send_from_directory
from werkzeug.utils import secure_filename
from flask_cors import CORS
from model import (
    all_skills,
    CAREERS,
    recommend_careers,
    skill_gap_analysis,
)
from pypdf import PdfReader
from docx import Document
from io import BytesIO
import re

app = Flask(__name__)

ALLOWED_EXTENSIONS = {"txt", "pdf", "docx"}

resume_data = {
    "filename": "",
    "text": "",
    "skills": []
}

user_profile = {
    "name": "",
    "education": "",
    "interests": [],
    "skills": []
}


@app.route("/")
def home():
    return send_from_directory(".", "index.html")


@app.route("/style.css")
def stylesheet():
    return send_from_directory(".", "style.css")


@app.route("/api/health")
def health():
    return jsonify({
        "status": "success",
        "message": "Career Intelligence AI is running"
    })


@app.route("/api/skills")
def get_skills():
    try:
        skills = all_skills()
        return jsonify({
            "skills": skills,
            "categories": skills
        })
    except Exception as error:
        return jsonify({"error": str(error)}), 500


@app.route("/api/careers")
def get_careers():
    return jsonify({"careers": CAREERS})


def extract_text_from_resume(file):
    filename = secure_filename(file.filename or "")
    extension = filename.rsplit(".", 1)[-1].lower()

    if extension not in ALLOWED_EXTENSIONS:
        raise ValueError("Upload a TXT, PDF, or DOCX resume.")

    file_bytes = file.read()

    if extension == "txt":
        return file_bytes.decode("utf-8", errors="ignore")

    if extension == "pdf":
        reader = PdfReader(BytesIO(file_bytes))
        return "\n".join(
            page.extract_text() or ""
            for page in reader.pages
        )

    if extension == "docx":
        document = Document(BytesIO(file_bytes))
        return "\n".join(
            paragraph.text for paragraph in document.paragraphs
        )

    return ""


def extract_skills_from_text(text):
    if not text:
        return []

    catalog = all_skills()
    if isinstance(catalog, dict):
        skill_names = [
            skill
            for items in catalog.values()
            if isinstance(items, list)
            for skill in items
        ]
    else:
        skill_names = catalog

    found_skills = []
    unique_skills = sorted(
        {str(skill).strip() for skill in skill_names if str(skill).strip()},
        key=len,
        reverse=True
    )

    for skill in unique_skills:
        if skill.lower().startswith(
            ("want to learn ", "beginner level ")
        ):
            continue

        pattern = r"(?<!\w)" + re.escape(skill.lower()) + r"(?!\w)"
        if re.search(pattern, text.lower()):
            found_skills.append(skill)

    return found_skills


@app.route("/api/resume", methods=["POST"])
def upload_resume():
    global resume_data

    file = request.files.get("resume") or request.files.get("file")

    if file is None or not file.filename:
        return jsonify({"error": "Please choose a resume file."}), 400

    try:
        text = extract_text_from_resume(file)
        skills = extract_skills_from_text(text)

        resume_data = {
            "filename": secure_filename(file.filename),
            "text": text,
            "skills": skills
        }

        return jsonify({
            "message": "Resume uploaded successfully.",
            "filename": resume_data["filename"],
            "text": text,
            "skills": skills,
            "skill_count": len(skills)
        })

    except ValueError as error:
        return jsonify({"error": str(error)}), 400
    except Exception as error:
        return jsonify({
            "error": f"Could not read the resume: {error}"
        }), 500


@app.route("/api/recommend", methods=["POST"])
def recommend():
    data = request.get_json(silent=True) or {}
    selected_skills = data.get("skills", [])

    if not isinstance(selected_skills, list):
        selected_skills = []

    combined_skills = list(selected_skills)
    for skill in resume_data["skills"]:
        if skill not in combined_skills:
            combined_skills.append(skill)

    try:
        results = recommend_careers(combined_skills)
        return jsonify({
            "skills": combined_skills,
            "recommendations": results,
            "resume_skills": resume_data["skills"]
        })
    except Exception as error:
        return jsonify({"error": str(error)}), 500


@app.route("/api/skill-gap", methods=["POST"])
def skill_gap():
    data = request.get_json(silent=True) or {}

    job_title = (
        data.get("job_title")
        or data.get("career")
        or data.get("role")
        or ""
    )

    selected_skills = data.get("skills", [])
    if not isinstance(selected_skills, list):
        selected_skills = []

    combined_skills = list(selected_skills)
    for skill in resume_data["skills"]:
        if skill not in combined_skills:
            combined_skills.append(skill)

    resume_text = data.get("resume_text") or resume_data["text"]

    if not job_title:
        return jsonify({
            "error": "Please select a career role."
        }), 400

    try:
        result = skill_gap_analysis(job_title, combined_skills)
        return jsonify({
            "career": job_title,
            "selected_skills": combined_skills,
            "resume_skills": resume_data["skills"],
            "resume_text": resume_text,
            "analysis": result,
            "skill_gap": result
        })
    except Exception as error:
        return jsonify({"error": str(error)}), 500


@app.route("/api/roadmap", methods=["POST"])
def roadmap():
    data = request.get_json(silent=True) or {}

    missing_skills = (
        data.get("missing_skills")
        or data.get("missingSkills")
        or data.get("skills_to_learn")
        or data.get("skills")
        or []
    )

    job_title = (
        data.get("job_title")
        or data.get("career")
        or data.get("role")
        or "Your Selected Career"
    )

    # Also accept the skill-gap response object directly.
    if isinstance(missing_skills, dict):
        missing_skills = (
            missing_skills.get("missing_skills")
            or missing_skills.get("missing")
            or missing_skills.get("skills_to_learn")
            or []
        )

    if not isinstance(missing_skills, list):
        missing_skills = []

    # Remove empty values and duplicate skills.
    cleaned_skills = []
    for skill in missing_skills:
        if isinstance(skill, str) and skill.strip():
            if skill.strip() not in cleaned_skills:
                cleaned_skills.append(skill.strip())

    # Helpful default if no missing skills were sent.
    if not cleaned_skills:
        cleaned_skills = [
            "Career fundamentals",
            "Practical skills",
            "Communication",
            "Project practice"
        ]

    roadmap_items = []

    for index, skill in enumerate(cleaned_skills, start=1):
        roadmap_items.append({
            "step": index,
            "title": f"Learn {skill}",
            "skill": skill,
            "duration": "1 week",
            "description": (
                f"Week {index}: Learn the basics of {skill}. "
                f"Watch beginner lessons, write short notes, and "
                f"practise {skill} with simple exercises."
            ),
            "activity": (
                f"Complete one small practical task using {skill}."
            ),
            "goal": (
                f"Explain {skill} in your own words and demonstrate "
                f"what you learned."
            )
        })

    return jsonify({
        "status": "success",
        "career": job_title,
        "roadmap": roadmap_items,
        "total_steps": len(roadmap_items),
        "message": "Your learning roadmap was created successfully."
    })


@app.route("/api/interview", methods=["POST"])
def interview():
    data = request.get_json(silent=True) or {}
    career = (
        data.get("career")
        or data.get("job_title")
        or "your chosen career"
    )

    questions = [
        f"Why are you interested in becoming a {career}?",
        f"What skills are important for a {career}?",
        "Describe a project or task you have completed.",
        "How do you solve a problem when you do not know the answer?",
        "What skill would you like to improve next?"
    ]

    return jsonify({
        "career": career,
        "questions": questions
    })


@app.route("/api/profile", methods=["GET", "POST"])
def profile():
    global user_profile

    if request.method == "POST":
        data = request.get_json(silent=True) or {}

        for key in ("name", "education", "interests", "skills"):
            if key in data:
                user_profile[key] = data[key]

    return jsonify({"profile": user_profile})


@app.route("/api/analytics")
def analytics():
    skills = all_skills()

    return jsonify({
        "total_careers": len(CAREERS),
        "resume_uploaded": bool(resume_data["filename"]),
        "resume_skill_count": len(resume_data["skills"]),
        "resume_filename": resume_data["filename"],
        "available_skill_categories": len(skills)
        if isinstance(skills, dict) else 1
    })


@app.errorhandler(404)
def not_found(error):
    return jsonify({
        "error": "The requested page or API endpoint was not found."
    }), 404


if __name__ == "__main__":
    app.run(debug=True)
