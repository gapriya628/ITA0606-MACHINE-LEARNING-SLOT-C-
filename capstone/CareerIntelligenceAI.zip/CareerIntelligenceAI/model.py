
import re

CATEGORIES = {
    "Technology & IT": """
    Python Programming, Java Programming, JavaScript, TypeScript, C Programming,
    C++ Programming, C# Programming, Go Programming, Rust Programming, PHP,
    Ruby, Kotlin, Swift, R Programming, MATLAB, HTML, CSS, React, Angular,
    Vue.js, Node.js, Express.js, Flask, Django, FastAPI, REST APIs, GraphQL,
    Web Development, Frontend Development, Backend Development, Full Stack Development,
    Mobile App Development, Android Development, iOS Development, Software Engineering,
    Data Structures, Algorithms, Debugging, Git, GitHub, Linux, Networking,
    Cybersecurity, Ethical Hacking, Cloud Computing, AWS, Azure, Google Cloud,
    Docker, Kubernetes, DevOps, CI/CD, Jenkins, GitHub Actions, Terraform,
    Database Management, SQL, MySQL, PostgreSQL, SQLite, MongoDB, Redis,
    Data Analysis, Data Science, Machine Learning, Deep Learning, Artificial Intelligence,
    Natural Language Processing, Computer Vision, Generative AI, Prompt Engineering,
    Large Language Models, AI Automation, Power BI, Tableau, Excel, Pandas, NumPy,
    Scikit-learn, TensorFlow, PyTorch, Matplotlib, Statistics, Data Visualization,
    Data Cleaning, Data Engineering, Big Data, Apache Spark, Hadoop, ETL,
    Software Testing, Manual Testing, Automation Testing, Selenium, API Testing,
    Performance Testing, Quality Assurance, UI UX Design, Wireframing, Prototyping,
    Figma, Adobe XD, Game Development, Unity, Unreal Engine, Robotics, IoT,
    Embedded Systems, Blockchain, Computer Hardware, Technical Support
    """,

    "Art & Creativity": """
    Drawing, Sketching, Painting, Watercolor Painting, Acrylic Painting,
    Oil Painting, Digital Art, Illustration, Portrait Drawing, Cartoon Drawing,
    Character Design, Graphic Design, Logo Design, Poster Design, Typography,
    Brand Identity Design, Photography, Wildlife Photography, Travel Photography,
    Product Photography, Photo Editing, Photoshop, Illustrator, Video Editing,
    Film Editing, Animation, 2D Animation, 3D Animation, Motion Graphics,
    Visual Effects, Blender, 3D Modelling, Interior Design, Fashion Design,
    Textile Design, Jewellery Design, Architecture, Landscape Design, Set Design,
    Makeup Artistry, Hair Styling, Craft Making, Handicrafts, Origami, Calligraphy,
    Sculpture, Pottery, Ceramics, Wood Art, Creative Writing, Poetry, Storytelling,
    Screenwriting, Script Writing, Film Direction, Cinematography, Acting,
    Voice Acting, Singing, Dancing, Choreography, Music Production, Guitar,
    Piano, Drumming, Sound Design, Music Composition, Theatre, Stage Performance,
    Costume Design, Art Direction, Content Creation, Comic Creation
    """,

    "Teaching & Communication": """
    Teaching, Tutoring, Online Teaching, Classroom Management, Lesson Planning,
    Curriculum Design, Student Mentoring, Career Counselling, Public Speaking,
    Presentation Skills, Communication, Active Listening, Technical Writing,
    Report Writing, Blog Writing, Copywriting, Editing, Proofreading, Translation,
    Interpretation, English Teaching, Language Teaching, Mathematics Teaching,
    Science Teaching, Computer Teaching, Debate, Journalism, Interviewing,
    Podcast Hosting, Broadcasting, News Reporting, Training, Corporate Training,
    Instructional Design, Coaching, Conflict Resolution, Negotiation, Teamwork,
    Leadership, Empathy, Customer Support, Customer Service, Client Communication,
    Social Media Communication, Persuasion, Networking, Mentoring
    """,

    "Business & Management": """
    Entrepreneurship, Business Analysis, Business Strategy, Project Management,
    Product Management, Operations Management, Team Management, Human Resources,
    Recruitment, Talent Acquisition, Marketing, Digital Marketing, Content Marketing,
    Social Media Marketing, Search Engine Optimization, SEO, Email Marketing,
    Affiliate Marketing, Influencer Marketing, Sales, Retail Sales, Lead Generation,
    Customer Relationship Management, Market Research, Competitor Analysis, Branding,
    Advertising, Campaign Management, Event Planning, Event Management,
    Business Development, Accounting, Bookkeeping, Financial Analysis,
    Financial Planning, Budgeting, Auditing, Taxation, Supply Chain Management,
    Logistics, Inventory Management, Procurement, E-commerce Management,
    Office Administration, Virtual Assistance, Data Entry, Scheduling,
    Documentation, Risk Management, Client Management
    """,

    "Science & Engineering": """
    Mathematics, Applied Mathematics, Statistics, Probability, Scientific Research,
    Laboratory Techniques, Biology, Microbiology, Biotechnology, Chemistry, Physics,
    Environmental Science, Ecology, Climate Science, Geology, Astronomy, Psychology,
    Sociology, Economics, Research Methodology, Data Collection, Experimental Design,
    Civil Engineering, Mechanical Engineering, Electrical Engineering, Electronics,
    Chemical Engineering, Aerospace Engineering, Automotive Engineering,
    Biomedical Engineering, Mechatronics, Industrial Engineering, CAD, AutoCAD,
    SolidWorks, Revit, 3D Printing, Renewable Energy, Solar Energy, Energy Management,
    Electrical Circuits, Robotics, Control Systems, GIS, Remote Sensing,
    Urban Planning, Sustainability, Waste Management, Water Quality, Food Science,
    Nutrition, Public Health, First Aid, Occupational Safety, Quality Control
    """,

    "Travel & Outdoors": """
    Travelling, Travel Planning, Tour Guiding, Tour Operations, Tourism Management,
    Travel Photography, Travel Blogging, Trip Budgeting, Itinerary Planning,
    Hospitality, Hotel Management, Guest Relations, Adventure Tourism, Camping,
    Hiking, Trekking, Mountaineering, Navigation, Map Reading, Wildlife Observation,
    Bird Watching, Gardening, Farming, Horticulture, Landscaping, Plant Care,
    Animal Care, Pet Care, Pet Grooming, Horse Riding, Fishing, Swimming, Cycling,
    Running, Yoga, Meditation, Fitness Training, Personal Training, Sports Coaching,
    Football, Cricket, Basketball, Volleyball, Badminton, Tennis, Martial Arts,
    Dance Fitness, Outdoor Education, Adventure Sports, Scuba Diving, Surfing,
    Nature Conservation, Survival Skills
    """,

    "Everyday & Practical Skills": """
    Cooking, Baking, Cake Decorating, Food Preparation, Meal Planning, Catering,
    Barista Skills, Food Safety, Tailoring, Sewing, Knitting, Embroidery, Carpentry,
    Woodworking, Plumbing, Electrical Work, Mechanical Repair, Automobile Repair,
    Bicycle Repair, Appliance Repair, Home Maintenance, DIY Projects, House Painting,
    Home Decoration, Organizing Spaces, Cleaning, Housekeeping, Driving,
    Delivery Operations, Cash Handling, Retail Service, Reception, Childcare,
    Elder Care, Personal Shopping, Personal Finance, Budget Planning, Pet Sitting,
    Basic Computer Skills, Typing, File Management, Internet Safety, Problem Solving,
    Decision Making, Critical Thinking, Adaptability, Organization, Time Management
    """,

    "Media & Online Work": """
    YouTube Content Creation, Short Video Creation, Reels Creation, Video Blogging,
    Blogging, Podcast Production, Live Streaming, Online Community Management,
    Content Strategy, Content Planning, Social Media Management, Social Media Analytics,
    Thumbnail Design, Video Scripting, Digital Storytelling, Freelance Writing,
    Freelance Design, Freelance Programming, Online Research, Transcription,
    Website Management, Online Customer Service, Digital Product Creation,
    Newsletter Writing, Personal Branding, Online Portfolio Creation, Digital Publishing,
    Advertising Copy, Audio Editing, Video Production, Audience Engagement,
    Community Moderation, Product Reviews, UGC Creation
    """,

    "Personal & Social Skills": """
    Leadership, Teamwork, Communication, Problem Solving, Critical Thinking,
    Creativity, Emotional Intelligence, Empathy, Active Listening, Conflict Resolution,
    Decision Making, Stress Management, Adaptability, Resilience, Self Motivation,
    Organization, Planning, Goal Setting, Collaboration, Accountability, Reliability,
    Patience, Negotiation, Relationship Building, Cultural Awareness, Interpersonal Skills,
    Attention to Detail, Analytical Thinking, Logical Reasoning, Initiative,
    Self Learning, Feedback Skills, Reflection, Research, Prioritization
    """
}


def normalize_skill(skill):
    return re.sub(r"[^a-z0-9]+", " ", str(skill).lower()).strip()


def skill_catalog():
    """Return all available skills grouped by category."""
    result = {}
    seen = set()

    for category, raw_skills in CATEGORIES.items():
        skills = []

        for item in raw_skills.replace("\n", " ").split(","):
            skill = " ".join(item.strip().split())
            key = skill.casefold()

            if skill and key not in seen:
                seen.add(key)
                skills.append(skill)

        result[category] = skills

    # Add useful learning-preference options for every base skill.
    base_skills = [
        skill
        for skills in result.values()
        for skill in skills
    ]

    result["Learning Preferences"] = [
        f"{skill} — Want to Learn"
        for skill in base_skills
    ]

    result["Skill Levels"] = [
        f"{skill} — Beginner"
        for skill in base_skills
    ]

    return result


CAREERS = [
    {
        "title": "Software Developer",
        "category": "Technology",
        "skills": [
            "Python Programming", "Data Structures", "Algorithms",
            "Git", "Software Testing", "REST APIs"
        ],
        "description": "Develops, tests, and maintains software applications."
    },
    {
        "title": "Data Analyst",
        "category": "Data & AI",
        "skills": [
            "Data Analysis", "SQL", "Excel", "Statistics",
            "Data Visualization", "Python Programming"
        ],
        "description": "Analyses data and communicates useful findings."
    },
    {
        "title": "Machine Learning Engineer",
        "category": "Data & AI",
        "skills": [
            "Python Programming", "Machine Learning", "Statistics",
            "Data Cleaning", "Data Visualization", "SQL"
        ],
        "description": "Develops and evaluates machine learning systems."
    },
    {
        "title": "Prompt Engineer",
        "category": "Data & AI",
        "skills": [
            "Prompt Engineering", "Generative AI", "Communication",
            "Critical Thinking", "Research"
        ],
        "description": "Designs and tests prompts for AI applications."
    },
    {
        "title": "Web Developer",
        "category": "Technology",
        "skills": [
            "HTML", "CSS", "JavaScript", "Web Development", "Git"
        ],
        "description": "Creates and maintains websites."
    },
    {
        "title": "UI/UX Designer",
        "category": "Design",
        "skills": [
            "UI UX Design", "Figma", "Wireframing",
            "Prototyping", "Communication"
        ],
        "description": "Designs user-friendly digital experiences."
    },
    {
        "title": "Graphic Designer",
        "category": "Creative",
        "skills": [
            "Graphic Design", "Typography", "Logo Design",
            "Photography", "Digital Art"
        ],
        "description": "Creates visual designs for brands and media."
    },
    {
        "title": "Artist / Illustrator",
        "category": "Creative",
        "skills": [
            "Drawing", "Sketching", "Painting",
            "Digital Art", "Illustration"
        ],
        "description": "Creates original artwork and illustrations."
    },
    {
        "title": "Photographer",
        "category": "Creative",
        "skills": [
            "Photography", "Photo Editing", "Travel Photography",
            "Communication"
        ],
        "description": "Takes and edits photographs."
    },
    {
        "title": "Video Editor",
        "category": "Media",
        "skills": [
            "Video Editing", "Film Editing", "Storytelling",
            "Audio Editing"
        ],
        "description": "Edits video content for different audiences."
    },
    {
        "title": "Film Director",
        "category": "Media",
        "skills": [
            "Film Direction", "Storytelling", "Screenwriting",
            "Leadership", "Cinematography"
        ],
        "description": "Guides the creative process of film production."
    },
    {
        "title": "Dancer / Choreographer",
        "category": "Performing Arts",
        "skills": [
            "Dancing", "Choreography", "Creativity",
            "Teamwork", "Fitness Training"
        ],
        "description": "Performs or creates dance routines."
    },
    {
        "title": "Actor / Performer",
        "category": "Performing Arts",
        "skills": [
            "Acting", "Voice Acting", "Storytelling",
            "Communication", "Teamwork"
        ],
        "description": "Performs in film, theatre, or digital media."
    },
    {
        "title": "Singer / Musician",
        "category": "Performing Arts",
        "skills": [
            "Singing", "Music Production", "Music Composition",
            "Instrument Playing"
        ],
        "description": "Creates or performs music."
    },
    {
        "title": "Teacher / Tutor",
        "category": "Education",
        "skills": [
            "Teaching", "Communication", "Lesson Planning",
            "Presentation Skills", "Empathy"
        ],
        "description": "Helps learners understand subjects."
    },
    {
        "title": "Travel Guide",
        "category": "Travel",
        "skills": [
            "Tour Guiding", "Communication", "Travel Planning",
            "Cultural Awareness", "Hospitality"
        ],
        "description": "Guides visitors and explains local attractions."
    },
    {
        "title": "Travel Content Creator",
        "category": "Media & Travel",
        "skills": [
            "Travelling", "Travel Photography", "Video Editing",
            "Storytelling", "Content Creation"
        ],
        "description": "Creates travel-related videos, photos, and stories."
    },
    {
        "title": "Chef / Baker",
        "category": "Food",
        "skills": [
            "Cooking", "Baking", "Food Preparation",
            "Food Safety", "Creativity"
        ],
        "description": "Prepares meals or baked products."
    },
    {
        "title": "Event Planner",
        "category": "Business",
        "skills": [
            "Event Planning", "Project Management", "Communication",
            "Budgeting", "Organization"
        ],
        "description": "Plans events, budgets, schedules, and suppliers."
    },
    {
        "title": "Digital Marketer",
        "category": "Business",
        "skills": [
            "Digital Marketing", "SEO", "Content Marketing",
            "Social Media Management", "Market Research"
        ],
        "description": "Promotes products and services online."
    },
    {
        "title": "Entrepreneur",
        "category": "Business",
        "skills": [
            "Entrepreneurship", "Business Strategy", "Marketing",
            "Budgeting", "Communication"
        ],
        "description": "Starts and manages a business."
    },
    {
        "title": "Fitness Trainer",
        "category": "Fitness",
        "skills": [
            "Fitness Training", "Communication", "Planning",
            "Motivation", "First Aid"
        ],
        "description": "Helps clients work towards fitness goals."
    },
    {
        "title": "Gardener",
        "category": "Nature",
        "skills": [
            "Gardening", "Plant Care", "Landscaping",
            "Planning", "Nature Conservation"
        ],
        "description": "Maintains plants, gardens, and green spaces."
    },
    {
        "title": "Customer Support Specialist",
        "category": "Service",
        "skills": [
            "Customer Support", "Communication", "Active Listening",
            "Problem Solving", "Documentation"
        ],
        "description": "Helps customers solve product or service issues."
    },
    {
        "title": "Cybersecurity Analyst",
        "category": "Technology",
        "skills": [
            "Cybersecurity", "Networking", "Linux",
            "Risk Management", "Critical Thinking"
        ],
        "description": "Helps identify and reduce security risks."
    },
    {
        "title": "Content Writer",
        "category": "Media",
        "skills": [
            "Creative Writing", "Research", "Editing",
            "Communication", "Storytelling"
        ],
        "description": "Creates articles, scripts, and other written content."
    },
    {
        "title": "Fashion Designer",
        "category": "Creative",
        "skills": [
            "Fashion Design", "Sketching", "Textile Design",
            "Creativity", "Pattern Making"
        ],
        "description": "Designs clothing and fashion products."
    },
    {
        "title": "Interior Designer",
        "category": "Design",
        "skills": [
            "Interior Design", "Space Planning", "Drawing",
            "CAD", "Communication"
        ],
        "description": "Plans functional and attractive interior spaces."
    },
    {
        "title": "Social Media Manager",
        "category": "Media",
        "skills": [
            "Social Media Management", "Content Planning",
            "Copywriting", "Analytics", "Communication"
        ],
        "description": "Plans and manages social media channels."
    },
    {
        "title": "Research Assistant",
        "category": "Research",
        "skills": [
            "Research", "Data Collection", "Statistics",
            "Documentation", "Critical Thinking"
        ],
        "description": "Supports research through data collection and analysis."
    },
    {
        "title": "Virtual Assistant",
        "category": "Online Work",
        "skills": [
            "Virtual Assistance", "Scheduling", "Documentation",
            "Communication", "Organization"
        ],
        "description": "Provides remote administrative support."
    }
]


def all_skills():
    return skill_catalog()


def skill_catalog():
    """Return skill categories with selectable learning preferences."""
    result = {}
    seen = set()

    for category, raw_skills in CATEGORIES.items():
        items = []
        for item in raw_skills.replace("\n", " ").split(","):
            skill = " ".join(item.strip().split())
            if skill and skill.casefold() not in seen:
                seen.add(skill.casefold())
                items.append(skill)
        result[category] = items

    base_skills = [s for values in result.values() for s in values]
    result["Want to Learn"] = [f"{s} — Want to Learn" for s in base_skills]
    result["Beginner Level"] = [f"{s} — Beginner" for s in base_skills]
    return result


def recommend_careers(selected_skills, resume_text=""):
    selected = {
        normalize_skill(s).replace(" want to learn", "").replace(" beginner", "")
        for s in (selected_skills or [])
    }
    resume = normalize_skill(resume_text)
    results = []

    for career in CAREERS:
        matched = []
        missing = []

        for skill in career["skills"]:
            key = normalize_skill(skill)
            if key in selected or (resume and key in resume):
                matched.append(skill)
            else:
                missing.append(skill)

        score = round(100 * len(matched) / max(len(career["skills"]), 1))
        results.append({
            **career,
            "matched_skills": matched,
            "missing_skills": missing,
            "match_score": score,
            "gap_count": len(missing)
        })

    return sorted(
        results,
        key=lambda item: (item["match_score"], -item["gap_count"]),
        reverse=True
    )


def skill_gap_analysis(job_title, selected_skills, resume_text=""):
    career = next(
        (c for c in CAREERS if c["title"].casefold() == str(job_title).casefold()),
        None
    )

    if not career:
        return {
            "error": "Career role not found",
            "available_roles": [c["title"] for c in CAREERS]
        }

    selected = {
        normalize_skill(s).replace(" want to learn", "").replace(" beginner", "")
        for s in (selected_skills or [])
    }
    resume = normalize_skill(resume_text)
    matched, gaps = [], []

    for skill in career["skills"]:
        key = normalize_skill(skill)

        if key in selected or (resume and key in resume):
            matched.append(skill)
        else:
            gaps.append({
                "skill": skill,
                "priority": "High" if len(gaps) < 3 else "Medium",
                "action": (
                    f"Learn {skill} fundamentals, practise with exercises, "
                    "and complete a small project."
                )
            })

    return {
        "job_title": career["title"],
        "required_skills": career["skills"],
        "matched_skills": matched,
        "missing_skills": gaps,
        "match_score": round(100 * len(matched) / max(len(career["skills"]), 1)),
        "learning_plan": [
            f"Week {i + 1}: Learn {item['skill']} and practise with a small project."
            for i, item in enumerate(gaps)
        ]
    }
